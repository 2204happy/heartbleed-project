export FLASK_APP=routes.py
flask run
