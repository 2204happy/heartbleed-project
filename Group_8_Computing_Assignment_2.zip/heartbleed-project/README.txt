All terminal commands assume your in the folder of the project

If you are using Mac of Linux run unix_start.bash
This can be done with the command "bash unix_start.bash" run in the terminal with out the quotation mark

If you are using windows run win_start.sh
This can be done with the command "win_start.sh" run in the terminal with out the quotation marks

note: win_start.sh is untested and may not work. For maximum reliabilty use linux. 


To views the website once it's running go to 127.0.0.1:5000 in your browser
